"Estado Inicial"
calif=0
respuestas_incorrectas=0
porcentaje_mal=(respuestas_incorrectas*10) 

print("El examen consiste de 10 preguntas. Cada una tiene valor de 1 si es contestada correctamente y de -1 si se comete un error. Si no conoces la respuesta, ingresa un 0 y no recibirás la penalización")
nombre=str(input("Ingrese su nombre"))


print("1.-¿Quién fue el creador de la tabla periodica?")
res1=str(input())
if res1 =="Dmitri Mendeléyev":
    calif=calif+1
elif res1 ==0:
    calif=calif+0
else:
    calif=calif-1
    respuestas_incorrectas=respuestas_incorrectas+1
    
print("2.-¿Cuál es el elemento más simple?")
res2=str(input())
if res2 =="Hidrógeno":
    calif=calif+1
elif res2 ==0:
    calif=calif+0
else:
    calif=calif-1
    respuestas_incorrectas=respuestas_incorrectas+1

print("3.-¿Cuantos electrones de valencia tiene el oxígeno si se encuentra en el grupo 6a y el periodo 2?")
res3=int(input())
if res3 == 6:
    calif=calif+1
elif res3 == 0:
    calif=calif+0
else:
    calif=calif-1
    respuestas_incorrectas=respuestas_incorrectas+1

print("4.-Ingrese el nombre que corresponda a los elementos más estables:")
res4=str(input())
if res4 == "gases nobles":
    calif=calif+1
elif res4 == 0:
    calif=calif+0
else:
    calif=calif-1
    respuestas_incorrectas=respuestas_incorrectas+1
    
print("5.-¿Qué tipo de carga poseen los electrones?(ingrese la respuesta con letra)")
res5=str(input())
if res5 == "negativa":
    calif=calif+1
elif res5 == 0:
    calif=calif+0
else:
    calif=calif-1
    respuestas_incorrectas=respuestas_incorrectas+1
    
print("6.-¿Cómo se denomina un átomo que ha perdido electrones?")
res6=str(input())
if res6 == "catión":
    calif=calif+1
elif res6 == 0:
    calif=calif+0
else:
    calif=calif-1
    respuestas_incorrectas=respuestas_incorrectas+1
    
print("7.-¿La fusión de un cubo de hielo a agua simple es un cambio químico o físico?")
res7=str(input())
if res7 == "físico":
    calif=calif+1
elif res7 == 0:
    calif=calif+0
else:
    calif=calif-1
    respuestas_incorrectas=respuestas_incorrectas+1
    
print("8.-¿Cuantos estados de la materia existen?")
res8=int(input())
if res8 == 5:
    calif=calif+1
elif res8 == 0:
    calif=calif+0
else:
    calif=calif-1
    respuestas_incorrectas=respuestas_incorrectas+1
    
print("9.-¿Cuántos elementos hay en la tabla periódica?")
res9=int(input())
if res9 == 118:
    calif=calif+1
elif res9 == 0:
    calif=calif+0
else:
    calif=calif-1
    respuestas_incorrectas=respuestas_incorrectas+1
    
print("10.-¿Cuál es el valor de pH neutro?")
res10=int(input())
if res10 == 7:
    calif=calif+1
elif res10 == 0:
    calif=calif+0
else:
    calif=calif-1
    respuestas_incorrectas=respuestas_incorrectas+1
    
porcentaje_mal=(respuestas_incorrectas*10)
    
print("Usuario:", nombre)
print("Calificación", calif)
print("Porcentaje de errores", porcentaje_mal)



